package org.escario.in3.model;

public class Value {
    public float temperature;
    public long time;

    public Value(float temperature, long time){
        this.temperature = temperature;
        this.time = time;
    }
}
