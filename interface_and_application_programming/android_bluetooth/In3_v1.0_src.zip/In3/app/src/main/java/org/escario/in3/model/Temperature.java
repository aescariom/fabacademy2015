package org.escario.in3.model;

public class Temperature {
    public float temperature;
    public long time;

    public Temperature(float temperature, long time){
        this.temperature = temperature;
        this.time = time;
    }
}
