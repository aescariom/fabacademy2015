package org.escario.bluetooth_console.fragments;

import android.app.Fragment;
import android.bluetooth.BluetoothSocket;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import org.escario.bluetooth_console.R;
import org.escario.bluetooth_console.model.Temperature;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by alejandro on 7/5/15.
 */
public class ConsoleFragment extends Fragment {

    private static BluetoothSocket socket;
    private View view;
    private TextView txvTarget;
    private TextView txvPartial;
    private EditText txtSend;
    private ImageButton btnSend;

    private List<Byte> rx = Collections.synchronizedList(new ArrayList<Byte>());
    private StringBuffer output = new StringBuffer();

    ArrayList<Temperature> temp_val, target;

    public ConsoleFragment(){
        temp_val = new ArrayList<>();
        target = new ArrayList<>();
    }

    public void setSocket(BluetoothSocket socket){
        this.socket = socket;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        if(view == null) {
            view = inflater.inflate(R.layout.console, container, false);
            txvTarget = (TextView) view.findViewById(R.id.txtTarget);
            txvPartial = (TextView) view.findViewById(R.id.txtPartial);
            txtSend = (EditText) view.findViewById(R.id.txtSend);
            btnSend = (ImageButton) view.findViewById(R.id.btnSend);
            btnSend.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String str = txtSend.getText().toString();
                    if(!str.isEmpty()) {
                        printBuffer(true);
                        txvTarget.append("\n\n------------------------\n");
                        txvTarget.append(str);
                        sendMessage(str);
                        txvTarget.append("\n------------------------\n");
                        txtSend.setText("");
                    }
                }
            });
        }
        return view;
    }


    @Override
    public void onDestroyView(){
        super.onStop();
        if(socket.isConnected()) {
            try {
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        if(!socket.isConnected()){
            try {
                socket.connect();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        // workaround to execute more than one asynctask at a time in Honeycomb
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
            new ListenThread().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, socket);
            new UpdateThread().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, (Void[]) null);
        } else {
            new ListenThread().execute(socket);
            new UpdateThread().execute((Void[]) null);
        }
    }

    private class ListenThread extends AsyncTask<BluetoothSocket, Byte, Void> {

        protected Void doInBackground(BluetoothSocket... socket) {
            byte[] buffer = new byte[6];
            byte[] read = new byte[1];
            try{
                InputStream is = socket[0].getInputStream();
                while(true){
                    int readBytes = is.read(read);
                    if(readBytes != -1) {
                        publishProgress(read[0]);
                    }
                }
            }catch(IOException e){
                e.printStackTrace();
            }
            return null;
        }

        protected void onProgressUpdate(Byte... val) {
            rx.add(val[0]);
        }
    };


    private class UpdateThread extends AsyncTask<Void, Void, Void> {

        private final static int TIME_LAPSE = 500;

        protected Void doInBackground(Void... val) {
            while(true){
                try {
                    Thread.sleep(TIME_LAPSE);
                    publishProgress();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }

        protected void onProgressUpdate(Void... val) {
            printBuffer(false);
        }
    };

    private void printBuffer(boolean clean){

        StringBuffer hexa = new StringBuffer();
        StringBuffer str = new StringBuffer();
        int i;
        synchronized(rx) {
            Iterator it = rx.iterator(); // Must be in synchronized block
            while (it.hasNext()) {
                Byte b = (Byte) it.next();
                hexa.append(String.format("%02X ", b));
                if(b >= 32 && b < 127) {
                    str.append(String.format("%c", b));
                }else{
                    str.append('.');
                }

                if(clean || rx.size() + str.length() >= 8){
                    it.remove();
                }

                if(str.length() == 8){
                    output.append("\n" + hexa.toString() + "\t\t" + str.toString());

                    str = new StringBuffer();
                    hexa = new StringBuffer();
                }
            }
        }
        if(output.length() > 0){
            txvTarget.append(output.toString());
            output = new StringBuffer();
        }
        if(clean){
            txvTarget.append(String.format("\n%-24s", hexa.toString()) + "\t\t" + str.toString());
            txvPartial.setText("");
        }else {
            txvPartial.setText(String.format("%-24s", hexa.toString()) + "\t\t" + str.toString());
        }
        /*sclTarget.post(new Runnable() { // waiting to paint before scrolling down
            public void run() {
                sclTarget.fullScroll(View.FOCUS_DOWN);
            }
        });*/
    }


    private void sendMessage(String msg){
        byte[] send;

        Pattern strPattern = Pattern.compile("^0x( [0-9A-Fa-f]{2})+$");
        Pattern bytePatterm = Pattern.compile("[0-9A-Fa-f]{2}");
        Matcher strMatcher = strPattern.matcher(msg);
        Matcher byteMatcher = bytePatterm.matcher(msg);
        if(strMatcher.matches()){
            ArrayList<Byte> bytes = new ArrayList<>();
            while(byteMatcher.find()){
                String hexaVal = msg.substring(byteMatcher.start(), byteMatcher.end());
                byte data = (byte) ((Character.digit(hexaVal.charAt(0), 16) << 4)
                        + Character.digit(hexaVal.charAt(1), 16));
                bytes.add(data);
            }
            send = Byte2byte(bytes);
        }else{
            send = msg.getBytes();
        }

        OutputStream os;
        try {
            os = socket.getOutputStream();
            os.write(send);
        }catch(IOException e){
            e.printStackTrace();
        }
    }

    public static byte[] Byte2byte(List<Byte> bytes)
    {
        byte[] ret = new byte[bytes.size()];
        for (int i=0; i < ret.length; i++)
        {
            ret[i] = bytes.get(i).byteValue();
        }
        return ret;
    }
}