
const serial = chrome.serial;
var connectionId;
var status = 1;
var fifth = -1;
var bytes = new Array();
var min = 9007199254740992;
var max = -9007199254740992;

function log(msg) {
  $('#status').append(msg.replace(/\n/g, '<br/>'));
  scroll2Bottom('#status');
}

function logLine(msg){
	log(msg + '<br/>')
}

function refresh(){
    serial.getDevices(function(devices) {
            for (var i = 0; i < devices.length; i++) {
                $('select#portList').append(new Option(devices[i].path, devices[i].path));
            }
        });
}

function connectionCompleted(connectionInfo) {
  if (!connectionInfo) {
    logLine("Connection failed.");
  }else{
    logLine("Connected");
  }
  connectionId = connectionInfo.connectionId;
  serial.onReceive.addListener(onReceive);
  serial.onReceiveError.addListener(onReceiveError);
};

function onReceive(receiveInfo) {
    if (receiveInfo.connectionId !== connectionId) {
        return;
    }
    var lineBuffer = ab2str(receiveInfo.data);
    log(lineBuffer);
    if(lineBuffer.length < 5){
        return;
    }
    var bytes = str2ba(lineBuffer);
    if(bytes[0] == 1 && bytes[1] == 2 && bytes[2] == 3 && bytes[3] == 4){
        numBytes = bytes[4];
        var val = 0;
        for(var i = 5, j = 1; i < bytes.length; ++i, ++j){
            despl = (j % numBytes);
            val |= (bytes[i] << (8*despl))
            if(despl == 0){
                display(0+val);
                val = 0;
            }
        }
    }
}

function onReceiveError(errorInfo) {
  if (errorInfo.connectionId === this.connectionId) {
    logLine('ERROR: ' + errorInfo.error);
  }
}

function display(value){
    if(value < min){
        min = value;
    }
    if(value > max){
        max = value;
    }
    percent = (value - min)/(max - min);
    percent *= 100;
    $('#percent').attr('value',percent);
    $('#intval').text(value + "(" + min + ", " + max + ") - " + percent + '%');
}

function scroll2Bottom(id){
	var elem    = $(id);
    elem.scrollTop(elem[0].scrollHeight);
}

$('#btnConnect').click(function() {
	path = $( "select#portList option:selected" ).text();
	path = "/dev/cu.usbserial-AH01DOWE";
    logLine('connecting to ' + path + '...')
    serial.connect(path, null, connectionCompleted);
});

$('#btnRefresh').click(function() {
    refresh();
});

$('#btnClear').click(function() {
    $('#status').html('');
});

refresh();


function ab2str(buf) {
  	encodedString = String.fromCharCode.apply(null, new Uint8Array(buf));
  	return decodeURIComponent(escape(encodedString));
}

function str2ba(str){
    var bytes = new Array();
    for (var i = 0; i < str.length; ++i){
        bytes.push(str.charCodeAt(i));
    }
    return bytes;
}



/* Converts a string to UTF-8 encoding in a Uint8Array; returns the array buffer. */
/*var str2ab = function(str) {
  var encodedString = unescape(encodeURIComponent(str));
  var bytes = new Uint8Array(encodedString.length);
  for (var i = 0; i < encodedString.length; ++i) {
    bytes[i] = encodedString.charCodeAt(i);
  }
  return bytes.buffer;
};*/

/*///////////////////////////////////////////////////////
////////////////////////////////////////////////////////

var SerialConnection = function() {
  this.connectionId = -1;
  this.lineBuffer = "";
  this.boundOnReceive = this.onReceive.bind(this);
  this.boundOnReceiveError = this.onReceiveError.bind(this);
  this.onConnect = new chrome.Event();
  this.onReadLine = new chrome.Event();
  this.onError = new chrome.Event();
};

SerialConnection.prototype.onConnectComplete = function(connectionInfo) {
  if (!connectionInfo) {
    log("Connection failed.");
    return;
  }
  this.connectionId = connectionInfo.connectionId;
  chrome.serial.onReceive.addListener(this.boundOnReceive);
  chrome.serial.onReceiveError.addListener(this.boundOnReceiveError);
  this.onConnect.dispatch();
};



SerialConnection.prototype.connect = function(path) {
  serial.connect(path, this.onConnectComplete.bind(this))
};

SerialConnection.prototype.send = function(msg) {
  if (this.connectionId < 0) {
    throw 'Invalid connection';
  }
  serial.send(this.connectionId, str2ab(msg), function() {});
};

SerialConnection.prototype.disconnect = function() {
  if (this.connectionId < 0) {
    throw 'Invalid connection';
  }
  serial.disconnect(this.connectionId, function() {});
};

////////////////////////////////////////////////////////
////////////////////////////////////////////////////////

var connection = new SerialConnection();

connection.onConnect.addListener(function() {
  log('connected to: ' + DEVICE_PATH);
  connection.send("hello arduino");
});

connection.onReadLine.addListener(function(line) {
  logJSON(line);
});

connection.connect(DEVICE_PATH);

function logJSON(ledstatus) {

  // Get the LED status from the Json returned by the Serial
  // 0 = off | 1 = on
  ledstatus = jQuery.parseJSON( ledstatus ).ledStatus ;

  // Set the circle color according with the LED status
  if (ledstatus == 0)
     $('#statusCircle').css('fill','red');
  else
    $('#statusCircle').css('fill','green');

  // Print led Status to HTML buffer area
  log(ledstatus)
}


function log(msg) {
  $('#buffer').append(msg + '<br/>');
}

var is_on = false;
$('button').click(function() {

  is_on = !is_on;
  connection.send(is_on ? 'y' : 'n');
});

*/